import React from 'react';
import ReactDOM from 'react-dom';
import  chai  from 'chai';
import spies from 'chai-spies'
import { shallow, mount, render } from 'enzyme';
import Game from './Game';

chai.use(spies);
const expect = chai.expect;

describe('The Game', () => {

  it('has 2 rows', () => {
    let app = shallow(<Game />);
    expect(app.find('.row').length).to.equal(2);
  });

  describe('when a winner has been decided', () => {

    it('shows x win message when notified with x', () => {
      let app = mount(<Game />);

      app.find('.square').at(0).simulate('click');
      app.find('.square').at(4).simulate('click');

      app.find('.square').at(3).simulate('click');
      app.find('.square').at(5).simulate('click');

      app.find('.square').at(6).simulate('click');
      app.find('.square').at(1).simulate('click');
      app.update();
      expect(app.find('#statusBox').text()).to.equal('The winner is: X');
    });

    it('shows O win message when notified with O', () => {
      let app = mount(<Game />);

      app.find('.square').at(1).simulate('click');
      app.find('.square').at(0).simulate('click');

      app.find('.square').at(2).simulate('click');
      app.find('.square').at(3).simulate('click');

      app.find('.square').at(5).simulate('click');
      app.find('.square').at(6).simulate('click');
      app.update();
      expect(app.find('#statusBox').text()).to.equal('The winner is: O');
    });


  });

});
