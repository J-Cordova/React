import React from 'react';
import GameBoard from './GameBoard'

export default class Game extends React.Component {


    constructor(props) {
        super(props);
        this.getStatusBoxMessageFromResult = this.getStatusBoxMessageFromResult.bind(this);
        this.reportCompletion = this.reportCompletion.bind(this);
        this.state = {
            status: ''
        }
    }

    reportCompletion(value)
    {
        var status = this.getStatusBoxMessageFromResult(value);
        this.setState({status: status});

  
    }

    getStatusBoxMessageFromResult(result)
    {
        if(result === 'X') return 'The winner is: X'
        if(result === 'O') return 'The winner is: O'
        if(result ==   null) return '';
        return 'There is no winner'
    }

    render()
    {
        return (
            <div>
                <div className='row'><GameBoard reportCompletion={this.reportCompletion} /></div>
                <div id='statusBox' className='row'>
                    {this.state.status}
                </div>
            </div>
            
        )
    }
    
}